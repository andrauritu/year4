Name: Uritu Andra-Ioana
Group: 1241EB