The first two exercises were solved individually, by:
Uritu Andra-Ioana

The third one was solved in a team formed of:
Uritu Andra-Ioana
El-Ghoul Layla
Mahmoud Mirghani Abdelrahman

We are all from group 1241EB